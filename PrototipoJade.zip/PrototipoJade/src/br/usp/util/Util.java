package br.usp.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.google.gson.Gson;

import br.usp.model.RegistroTratado;

public class Util {
	
	public static void delay(int _tempoSleep, String mensagem) {
		try {
			System.out.println(mensagem);
			Thread.sleep(_tempoSleep);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void delay(int tempoSleep) {
		try {
			Thread.sleep(tempoSleep);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static StringBuffer recuperarDados() {
		int HTTP_COD_SUCESSO = 200;
		Gson gson = new Gson();
		StringBuffer buffer = new StringBuffer();
		
		try {
			URL url = new URL("http://balthazar83.jelastic.saveincloud.net/ROOT-896/RecuperarRegistroRecente.do");
			HttpURLConnection con = (HttpURLConnection) url.openConnection();

			if (con.getResponseCode() != HTTP_COD_SUCESSO) {
				throw new RuntimeException("HTTP error code : " + con.getResponseCode());
			}

			BufferedReader reader = new BufferedReader(new InputStreamReader((con.getInputStream())));

			String linha;
			while ((linha = reader.readLine()) != null) {
				buffer.append(linha);
			}
			
			con.disconnect();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return buffer;
	}
	
	public static void gravarRegistrosTratados(RegistroTratado regTratado) {
		int HTTP_COD_SUCESSO = 200;
		Gson gson = new Gson();
		StringBuffer buffer = new StringBuffer();
		
		try {
			String uri = "http://balthazar83.jelastic.saveincloud.net/ROOT-896/GravarRegistroTratadoService.do?temperatura_c="+regTratado.getTemperatura_c()+"&temperatura_c_situacao="+regTratado.getTemperatura_c_situacao()+"&umidade_relativa="+regTratado.getUmidade_relativa()+"&umidade_relativa_situacao="+regTratado.getUmidade_relativa_situacao()+"&pressao_atm="+regTratado.getPressao_atm()+"&pressao_atm_situacao="+regTratado.getPressao_atm_situacao()+"&situacao_entalpia="+regTratado.getSituacaoEntalpia();
			System.out.println("Orchestrator: The enthalpy for the current situation is: "+regTratado.getSituacaoEntalpia());
			URL url = new URL(uri);
						
			
			HttpURLConnection con = (HttpURLConnection) url.openConnection();

			if (con.getResponseCode() != HTTP_COD_SUCESSO) {
				throw new RuntimeException("HTTP error code : " + con.getResponseCode());
			}

			BufferedReader reader = new BufferedReader(new InputStreamReader((con.getInputStream())));

			String linha;
			while ((linha = reader.readLine()) != null) {
				buffer.append(linha);
			}
			
			con.disconnect();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}

}
