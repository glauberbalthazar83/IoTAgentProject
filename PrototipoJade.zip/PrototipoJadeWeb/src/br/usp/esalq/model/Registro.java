package br.usp.esalq.model;

public class Registro {
	private int pk_registro;
	private double temperatura_c;
	private double umidade_relativa;
	private double pressao_atm;
	private String data;  
	private String hora;
	
	
	public int getPk_registro() {
		return pk_registro;
	}
	public void setPk_registro(int pk_registro) {
		this.pk_registro = pk_registro;
	}
	public double getTemperatura_c() {
		return temperatura_c;
	}
	public void setTemperatura_c(double temperatura_c) {
		this.temperatura_c = temperatura_c;
	}
	public double getUmidade_relativa() {
		return umidade_relativa;
	}
	public void setUmidade_relativa(double umidade_relativa) {
		this.umidade_relativa = umidade_relativa;
	}
	public double getPressao_atm() {
		return pressao_atm;
	}
	public void setPressao_atm(double pressao_atm) {
		this.pressao_atm = pressao_atm;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getHora() {
		return hora;
	}
	public void setHora(String hora) {
		this.hora = hora;
	}

}
