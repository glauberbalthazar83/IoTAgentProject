package br.usp.model;

import com.google.gson.Gson;

public class Mensagem {
	private String tipoEmissor;
	private double valor;
	private String situacao;
	
	public Mensagem() {
		
	}
	
	public Mensagem(String _tipoEmissor, double _valor, String _situacao) {
		tipoEmissor = _tipoEmissor;
		valor = _valor;
		situacao = _situacao;
	}	
	
	public String getTipoEmissor() {
		return tipoEmissor;
	}
	public void setTipoEmissor(String tipoEmissor) {
		this.tipoEmissor = tipoEmissor;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public String getSituacao() {
		return situacao;
	}
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public String toString() {
		return "Issuer Type: "+tipoEmissor+", value: "+valor+", situation: "+situacao;
	}
}
