package br.usp.esalq.services;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.usp.esalq.dao.RegistroDAO;
import br.usp.esalq.dao.RegistroTratadoDAO;
import br.usp.esalq.model.Registro;
import br.usp.esalq.model.RegistroTratado;

public class GravarRegistroTratadoService extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public GravarRegistroTratadoService() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.executar(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.executar(request, response);
	}
	
	protected void executar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RegistroTratado reg =  new RegistroTratado();
		RegistroTratadoDAO regDAO = new RegistroTratadoDAO();
		
		reg.setTemperatura_c(Double.parseDouble(request.getParameter("temperatura_c")));
		reg.setTemperatura_c_situacao(request.getParameter("temperatura_c_situacao"));
		reg.setUmidade_relativa(Double.parseDouble(request.getParameter("umidade_relativa")));
		reg.setUmidade_relativa_situacao(request.getParameter("umidade_relativa_situacao"));
		reg.setPressao_atm(Double.parseDouble(request.getParameter("pressao_atm")));
		reg.setPressao_atm_situacao(request.getParameter("pressao_atm_situacao"));
		reg.setSituacaoEntalpia(request.getParameter("situacao_entalpia"));
		
		regDAO.gravar(reg);
	}

}
