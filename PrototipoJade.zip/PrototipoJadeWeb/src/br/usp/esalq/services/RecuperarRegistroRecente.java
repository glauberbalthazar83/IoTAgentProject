package br.usp.esalq.services;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import br.usp.esalq.dao.RegistroDAO;
import br.usp.esalq.model.Registro;

public class RecuperarRegistroRecente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RecuperarRegistroRecente() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.executar(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.executar(request, response);
	}

	protected void executar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RegistroDAO regDAO = new RegistroDAO();
		Registro reg = regDAO.buscarRegistroRecente();

		if (reg != null) {
			Gson gson = new Gson();
			String leiturasJsonString = gson.toJson(reg);

			PrintWriter out = response.getWriter();
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			out.print(leiturasJsonString);
			out.flush();
		}else {
			PrintWriter out = response.getWriter();
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			out.print("Sem registro para retorno");
			out.flush();
		}
	}

}
