package br.usp.esalq.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class DBConnectionMySQL {
	protected Connection conn = null;
	protected String userName = "xxx";
	protected String password = "xxxx";
	protected String dbName = "bd_prototipo_jade";
	protected Statement sql;
	protected static final Logger logger = LogManager.getLogger(DBConnectionMySQL.class);

	public DBConnectionMySQL() {
		if (this.conn == null) {
			this.conn = this.getConnection();
		}
	}

	public Connection getConnection(){

		String url = "jdbc:mysql://xxxx:3306/";
		String driver = "com.mysql.jdbc.Driver";

		try {
			Class.forName(driver).newInstance();
			conn = DriverManager.getConnection(url + dbName, userName, password);
		} catch (Exception ex) {
			logger.debug("Erro na conexao com o BD");
			logger.error(ex.getMessage());
			ex.printStackTrace();
		}

		return this.conn;
	}

	public ResultSet buscarRegistros(String queryComando) throws SQLException {
		ResultSet registros = null;
		sql = conn.createStatement();
		registros = sql.executeQuery(queryComando);
		return registros;
	}

	public boolean executarComando(String queryComando) throws SQLException {
		boolean resultado = false;
		sql = conn.createStatement();
		sql.execute(queryComando);
		resultado = true;
		return resultado;
	}

	public void fecharConexao() throws SQLException {
		if (this.conn != null) {
			this.conn.close();
			this.conn = null;
		}
	}

}