package br.usp.esalq.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.TimeZone;

import br.usp.esalq.db.DBConnectionMySQL;
import br.usp.esalq.model.Registro;
import br.usp.esalq.model.RegistroTratado;;

public class RegistroTratadoDAO {
	
	DBConnectionMySQL dbConnectionMySQL = new DBConnectionMySQL();

	
	public boolean gravar(RegistroTratado reg) {
		String horaStr = "";
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/Sao_Paulo"));
		int hora = calendar.get(Calendar.HOUR_OF_DAY);
		int minuto = calendar.get(Calendar.MINUTE);
		int segundo = calendar.get(Calendar.SECOND);
		horaStr = hora+":"+minuto+":"+segundo;

		String insertSQL = "insert into registros_tratados "
				+ "(temperatura_c,temperatura_c_situacao,umidade_relativa,umidade_relativa_situacao,pressao_atm,pressao_atm_situacao,situacao_entalpia,data,hora) values " 
				+ "(" + reg.getTemperatura_c() 
				+ ",'" + reg.getTemperatura_c_situacao()+"'"
				+ "," + reg.getUmidade_relativa()
				+ ",'" + reg.getUmidade_relativa_situacao()+"'"
				+ "," + reg.getPressao_atm()
				+ ",'" + reg.getPressao_atm_situacao()+"'"
				+ ",'" + reg.getSituacaoEntalpia()+"'"
				+ ",'" + LocalDateTime.now()+"'"
				+ ",'" + horaStr+"')";
		try {
			dbConnectionMySQL.executarComando(insertSQL);
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}
	
	public RegistroTratado buscarRegistroTratadoRecente(){
		RegistroTratado a = null;
	    String findSQL = "select * from registros_tratados ORDER BY pk_registro DESC LIMIT 1";
	    try {
	        ResultSet resultados = dbConnectionMySQL.buscarRegistros(findSQL);
	        while(resultados.next()){
	        	a = new RegistroTratado();
	        	a.setPk_registro(Integer.parseInt(resultados.getString("pk_registro")));
	        	a.setHora(resultados.getString("hora"));
	        	a.setData(resultados.getString("data"));
	        	a.setPressao_atm(Double.parseDouble(resultados.getString("pressao_atm")));
	        	a.setPressao_atm_situacao(resultados.getString("pressao_atm_situacao"));	        	
	        	a.setTemperatura_c(Double.parseDouble(resultados.getString("temperatura_c")));
	        	a.setTemperatura_c_situacao(resultados.getString("temperatura_c_situacao"));	        	
	        	a.setUmidade_relativa(Double.parseDouble(resultados.getString("umidade_relativa")));
	        	a.setUmidade_relativa_situacao(resultados.getString("umidade_relativa_situacao"));
	        	a.setSituacaoEntalpia(resultados.getString("situacao_entalpia"));
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return a;
    }
	
	
}
