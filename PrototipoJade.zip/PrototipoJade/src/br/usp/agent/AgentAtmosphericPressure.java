package br.usp.agent;

import br.usp.behaviour.SensorBehaviour;
import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

public class AgentAtmosphericPressure  extends Agent{
	private SensorBehaviour sensor;
	
	public void setup() {
		System.out.println("Hi! I am the agent "+getLocalName()+", I'm responsible for monitoring Atmospheric Pressure and I'm just born!");
		sensor = new SensorBehaviour(this);
		sensor.setAcao("pressao");
		//3rd week of production - broiler
		sensor.setMax(725);
		sensor.setMin(658);
		addBehaviour(sensor);
	}
	
}
