package br.usp.esalq.model;

public class RegistroTratado {
	private int pk_registro;
	private double temperatura_c = -1;
	private String temperatura_c_situacao;
	private double umidade_relativa = -1;
	private String umidade_relativa_situacao;
	private double pressao_atm = -1;
	private String pressao_atm_situacao;
	private String situacao_entalpia;
	private String data;  
	private String hora;
	
	public int getPk_registro() {
		return pk_registro;
	}
	public void setPk_registro(int pk_registro) {
		this.pk_registro = pk_registro;
	}
	public double getTemperatura_c() {
		return temperatura_c;
	}
	public void setTemperatura_c(double temperatura_c) {
		this.temperatura_c = temperatura_c;
	}
	public String getTemperatura_c_situacao() {
		return temperatura_c_situacao;
	}
	public void setTemperatura_c_situacao(String temperatura_c_situacao) {
		this.temperatura_c_situacao = temperatura_c_situacao;
	}
	public double getUmidade_relativa() {
		return umidade_relativa;
	}
	public void setUmidade_relativa(double umidade_relativa) {
		this.umidade_relativa = umidade_relativa;
	}
	public String getUmidade_relativa_situacao() {
		return umidade_relativa_situacao;
	}
	public void setUmidade_relativa_situacao(String umidade_relativa_situacao) {
		this.umidade_relativa_situacao = umidade_relativa_situacao;
	}
	public double getPressao_atm() {
		return pressao_atm;
	}
	public void setPressao_atm(double pressao_atm) {
		this.pressao_atm = pressao_atm;
	}
	public String getPressao_atm_situacao() {
		return pressao_atm_situacao;
	}
	public void setPressao_atm_situacao(String pressao_atm_situacao) {
		this.pressao_atm_situacao = pressao_atm_situacao;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getHora() {
		return hora;
	}
	public void setHora(String hora) {
		this.hora = hora;
	}
	public String getSituacaoEntalpia() {
		return situacao_entalpia;
	}
	public void setSituacaoEntalpia(String situacaoEntalpia) {
		this.situacao_entalpia = situacaoEntalpia;
	}

}