package br.usp.behaviour;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import br.usp.agent.AgentTemperature;
import br.usp.model.Mensagem;
import br.usp.model.Registro;
import br.usp.util.Util;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;
import jade.lang.acl.ACLMessage;

public class SensorBehaviour extends SimpleBehaviour {
	private boolean finished = true;
	private String acao;
	private double max;
	private double min;
	private Gson gson = new Gson();
	private Agent agent;

	public SensorBehaviour(Agent a) {
		super(a);
		agent = a;
	}

	public void action() {
		while (true) {
			//unusual situation control flag
			boolean anomalia = false;
			//retrieve data from remote server in JSON
			StringBuffer buffer = Util.recuperarDados();
			TypeToken<Registro> token = new TypeToken<Registro>() {};
			Registro registro = (Registro) gson.fromJson(buffer.toString(),token.getType());
			ACLMessage msgSerEnviada;
			
			switch (acao) {
				case "temperature":
					//message builder for orchestrator
					msgSerEnviada = new ACLMessage(ACLMessage.INFORM);
					if(registro.getTemperatura_c()>max) {
						anomalia = true;
						System.out.println("Attention: the temperature is above normal");
						Mensagem m = new Mensagem("temperature",registro.getTemperatura_c(),"above");						
						msgSerEnviada.setContent(gson.toJson(m));
					}
					if(registro.getTemperatura_c()<min) {
						anomalia = true;
						System.out.println("Attention: the temperature is below normal");
						Mensagem m = new Mensagem("temperature",registro.getTemperatura_c(),"below");
						msgSerEnviada.setContent(gson.toJson(m));
					}
					if(anomalia==false) {
						System.out.println("Rest assured... the temperature is normal!");
						Mensagem m = new Mensagem("temperature",registro.getTemperatura_c(),"normal");
						msgSerEnviada.setContent(gson.toJson(m));
					}
					msgSerEnviada.addReceiver(new AID("orchestrator",AID.ISLOCALNAME));
					agent.send(msgSerEnviada);
					Util.delay(400);
					break;
				case "humidity":
					msgSerEnviada = new ACLMessage(ACLMessage.INFORM);
					if(registro.getUmidade_relativa()>max) {
						anomalia = true;
						System.out.println("Attention: the humidity is above normal");
						Mensagem m = new Mensagem("humidity",registro.getUmidade_relativa(),"above");
						msgSerEnviada.setContent(gson.toJson(m));
					}
					if(registro.getUmidade_relativa()<min) {
						anomalia = true;
						System.out.println("Attention: humidity is below normal");
						Mensagem m = new Mensagem("humidity",registro.getUmidade_relativa(),"below");
						msgSerEnviada.setContent(gson.toJson(m));
					}
					if(anomalia==false) {
						System.out.println("Rest assured... the humidity is normal!");
						Mensagem m = new Mensagem("humidity",registro.getUmidade_relativa(),"normal");
						msgSerEnviada.setContent(gson.toJson(m));
					}
					msgSerEnviada.addReceiver(new AID("orchestrator",AID.ISLOCALNAME));
					agent.send(msgSerEnviada);
					Util.delay(650);
					break;
				case "pressao":
					msgSerEnviada = new ACLMessage(ACLMessage.INFORM);
					if(registro.getPressao_atm()>max) {
						anomalia = true;
						System.out.println("Attention: atmospheric pressure is above normal");
						Mensagem m = new Mensagem("pressao",registro.getPressao_atm(),"above");
						msgSerEnviada.setContent(gson.toJson(m));
					}
					if(registro.getPressao_atm()<min) {
						anomalia = true;
						System.out.println("Attention: atmospheric pressure is below normal");
						Mensagem m = new Mensagem("pressao",registro.getPressao_atm(),"");
						msgSerEnviada.setContent(gson.toJson(m));
					}
					if(anomalia==false) {
						Mensagem m = new Mensagem("pressao",registro.getPressao_atm(),"normal");
						System.out.println("Attention: atmospheric pressure is normal");
						msgSerEnviada.setContent(gson.toJson(m));
					}
					msgSerEnviada.addReceiver(new AID("orchestrator",AID.ISLOCALNAME));
					agent.send(msgSerEnviada);
					Util.delay(850);
					break;
			}
			//Util.delay(240000);//4 minutes
			Util.delay(60000);//1 minutes
		}
	}

	public boolean done() {
		return finished;
	}

	public String getAcao() {
		return acao;
	}

	public void setAcao(String acao) {
		this.acao = acao;
	}

	public double getMax() {
		return max;
	}

	public void setMax(double max) {
		this.max = max;
	}

	public double getMin() {
		return min;
	}

	public void setMin(double min) {
		this.min = min;
	}
}
