import java.util.Calendar;
import java.util.TimeZone;

public class Main {

	public static void main(String[] args) {
		String horaStr = "";
		/*horaStr += LocalDateTime.now().getHour() + ":";
		horaStr += LocalDateTime.now().getMinute() + ":";
		horaStr += LocalDateTime.now().getSecond();
		System.out.println(horaStr);
		System.out.println(TimeZone.getDefault());*/
		
		//Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("Brazil/East"));
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/Sao_Paulo"));
		int hora = calendar.get(Calendar.HOUR_OF_DAY);
		int minuto = calendar.get(Calendar.MINUTE);
		int segundo = calendar.get(Calendar.SECOND);
		
		horaStr = hora+":"+minuto+":"+segundo;
		System.out.println(horaStr);
	}

}
