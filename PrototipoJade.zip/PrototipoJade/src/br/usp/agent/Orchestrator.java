package br.usp.agent;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import br.usp.model.Mensagem;
import br.usp.model.Registro;
import br.usp.model.RegistroTratado;
import br.usp.util.Util;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class Orchestrator extends Agent{
	private double entalpia;
	private Gson gson = new Gson();
	private RegistroTratado regTratado =  new RegistroTratado();
	
	protected void setup() {
		System.out.println("Hi! I am the Orchestrator "+getLocalName()+", I am responsible for monitoring all agents in this world!");
		addBehaviour(new CyclicBehaviour() {
			
			@Override
			public void action() {
				while(true) {
					ACLMessage msg = receive();
					if(msg !=null) {
						TypeToken<Mensagem> token = new TypeToken<Mensagem>() {};
						Mensagem mensagem = (Mensagem) gson.fromJson(msg.getContent().toString(),token.getType());
						
						//handle Temperature Agent message
						if(mensagem.getTipoEmissor().equals("temperature")) {
							System.out.println("Orchestrator: I just got a message from the Temperature Agent. Message received: "+mensagem);
							regTratado.setTemperatura_c(mensagem.getValor());
							regTratado.setTemperatura_c_situacao(mensagem.getSituacao());
						}
						
						//handle Moisture Agent message
						if(mensagem.getTipoEmissor().equals("humidity")) {
							System.out.println("Orchestrator: I just received a message from the Moisture Agent. Message received: "+mensagem);
							regTratado.setUmidade_relativa(mensagem.getValor());
							regTratado.setUmidade_relativa_situacao(mensagem.getSituacao());
						}
						
						//handle Atm Pressure Agent message
						if(mensagem.getTipoEmissor().equals("pressao")) {
							System.out.println("Orchestrator: I just got a message from the Atmospheric Pressure Agent. Message received: "+mensagem);
							regTratado.setPressao_atm(mensagem.getValor());
							regTratado.setPressao_atm_situacao(mensagem.getSituacao());
						}
						
						if(regTratado.getTemperatura_c()!=-1 && regTratado.getPressao_atm()!=-1 && regTratado.getUmidade_relativa()!=-1) {
							//calculate enthalpy
							entalpia = (1.006 * regTratado.getTemperatura_c()) + ((regTratado.getUmidade_relativa()/regTratado.getPressao_atm())) * Math.pow(10,((7.5 * regTratado.getTemperatura_c())/(237.3+regTratado.getTemperatura_c())))*(71.28+(0.054*regTratado.getTemperatura_c()));
							//simulate situation for broiler birds - 3rd week
							if(entalpia<=48.5 || entalpia>=101.4){
			                    regTratado.setSituacaoEntalpia("serious");
			                }else{
			                    if((entalpia>=48.6 && entalpia<=62.7) || (entalpia>=62.8 && entalpia<=80.0)){
			                    	regTratado.setSituacaoEntalpia("attention");
			                    }else{
			                    	regTratado.setSituacaoEntalpia("normal");
			                    }
			                }
							Util.gravarRegistrosTratados(regTratado);
							//write result to database
							regTratado = new RegistroTratado();
						}
						
						
					}
					block();
					Util.delay(1000);
				}
			}
		});
		
	}

}