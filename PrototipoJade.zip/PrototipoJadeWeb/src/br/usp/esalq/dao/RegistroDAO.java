package br.usp.esalq.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

import br.usp.esalq.db.DBConnectionMySQL;
import br.usp.esalq.model.Registro;

public class RegistroDAO {

	DBConnectionMySQL dbConnectionMySQL = new DBConnectionMySQL();

	public boolean gravarRegistroLeitura(Registro reg) {
		String horaStr = "";
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("America/Sao_Paulo"));
		int hora = calendar.get(Calendar.HOUR_OF_DAY);
		int minuto = calendar.get(Calendar.MINUTE);
		int segundo = calendar.get(Calendar.SECOND);
		horaStr = hora+":"+minuto+":"+segundo;

		String insertSQL = "insert into registros "
				+ "(data,hora,pressao_atm,umidade_relativa,temperatura_c) values " + "('"
				+ LocalDateTime.now() + "','" + horaStr + "'," + reg.getPressao_atm() + ","
				+ reg.getUmidade_relativa() + "," + reg.getTemperatura_c() + ")";
		try {
			dbConnectionMySQL.executarComando(insertSQL);
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}
	
	public ArrayList<Registro> buscarTodosRegistros(){
	    ArrayList<Registro> registroLeituras = new ArrayList<Registro>();
	    String findSQL = "select * from registros ORDER BY pk_registro DESC";
	    try {
	        ResultSet resultados = dbConnectionMySQL.buscarRegistros(findSQL);
	        while(resultados.next()){
	        	Registro a = new Registro();
	        	a.setPk_registro(Integer.parseInt(resultados.getString("pk_registro")));
	        	a.setHora(resultados.getString("hora"));
	        	a.setData(resultados.getString("data"));
	        	a.setPressao_atm(Double.parseDouble(resultados.getString("pressao_atm")));
	        	a.setTemperatura_c(Double.parseDouble(resultados.getString("temperatura_c")));
	        	a.setUmidade_relativa(Double.parseDouble(resultados.getString("umidade_relativa")));	        	
	            registroLeituras.add(a);
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return registroLeituras;
    }
	
	public Registro buscarRegistroRecente(){
	    Registro a = null;
	    String findSQL = "select * from registros ORDER BY pk_registro DESC LIMIT 1";
	    try {
	        ResultSet resultados = dbConnectionMySQL.buscarRegistros(findSQL);
	        while(resultados.next()){
	        	a = new Registro();
	        	a.setPk_registro(Integer.parseInt(resultados.getString("pk_registro")));
	        	a.setHora(resultados.getString("hora"));
	        	a.setData(resultados.getString("data"));
	        	a.setPressao_atm(Double.parseDouble(resultados.getString("pressao_atm")));
	        	a.setTemperatura_c(Double.parseDouble(resultados.getString("temperatura_c")));
	        	a.setUmidade_relativa(Double.parseDouble(resultados.getString("umidade_relativa")));	        	
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	    return a;
    }

}
